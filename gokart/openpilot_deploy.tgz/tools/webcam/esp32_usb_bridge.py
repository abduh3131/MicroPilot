#!/usr/bin/env python3
import os
import cv2
import time
import threading
import numpy as np
import av
import serial
import io
from PIL import Image
from cereal import messaging, car
from msgq.visionipc import VisionIpcServer, VisionStreamType
from openpilot.common.params import Params

# Configuration
# connection_type can be "URL", "INDEX" (UVC), or "SERIAL"
CONNECTION_TYPE = os.getenv("ESP32_TYPE", "SERIAL")

# For URL (WiFi)
ESP32_URL = os.getenv("ESP32_URL", "http://192.168.1.100:81/stream")

# For INDEX (UVC USB Webcam)
CAMERA_INDEX = int(os.getenv("CAMERA_INDEX", 0))

# For SERIAL
SERIAL_PORT = os.getenv("SERIAL_PORT", "COM3")
BAUD_RATE = int(os.getenv("BAUD_RATE", 921600))

TARGET_W, TARGET_H = 1928, 1208
FRAMERATE = 20


class ESP32Bridge:
  def __init__(self):
    self.pm = messaging.PubMaster(['roadCameraState', 'deviceState', 'carParams', 'carState', 'pandaStates'])
    self.vipc_server = VisionIpcServer("camerad")

    # Create buffers for road camera
    self.vipc_server.create_buffers(VisionStreamType.VISION_STREAM_ROAD, 40, TARGET_W, TARGET_H)
    self.vipc_server.start_listener()

    self.running = True
    self.ser = None

    # Initialize Params for offroad -> onroad transition
    self.params = Params()
    self.params.put_bool("IsDriverViewEnabled", False)
    self.params.put_bool("Passive", False)
    self.params.put_bool("OpenpilotEnabledToggle", True)

  def rgb_to_nv12(self, bgr):
    frame = av.VideoFrame.from_ndarray(bgr, format='bgr24')
    return frame.reformat(format='nv12').to_ndarray()

  def publish_system_state(self):
    """
    Simulates the car and device state to engage openpilot controls
    """
    frame_count = 0
    while self.running:
      # 1. DeviceState (Keep alive)
      dat = messaging.new_message('deviceState')
      dat.deviceState.deviceType = "pc"
      dat.deviceState.started = True
      dat.deviceState.startIdx = 0
      self.pm.send('deviceState', dat)

      # 2. CarParams (Tell openpilot what car we are "driving")
      # We send this once every few seconds, or usually once at startup is enough but in loop is safer for hot-plug
      if frame_count % 100 == 0:
        cp = messaging.new_message('carParams')
        cp.carParams.carFingerprint = "MOCK"
        cp.carParams.openpilotLongitudinalControl = True
        cp.carParams.brand = "mock"
        self.pm.send('carParams', cp)
        # Also put in params for manager
        self.params.put("CarParams", cp.carParams.as_builder().to_bytes())

      # 3. CarState (Simulate driving)
      # We need velocity > 0 for planner to produce non-stationary path
      cs = messaging.new_message('carState')
      cs.carState.vEgo = 30.0  # 30 m/s ~ 65 mph
      cs.carState.gearShifter = car.CarState.GearShifter.drive
      cs.carState.steeringPressed = False
      cs.carState.gasPressed = False
      cs.carState.cruiseState.enabled = True
      cs.carState.cruiseState.available = True
      cs.carState.cruiseState.speed = 30.0
      self.pm.send('carState', cs)

      # 4. PandaStates (Ignition)
      ps = messaging.new_message('pandaStates', 1)
      ps.pandaStates[0].ignitionLine = True
      ps.pandaStates[0].pandaType = "dos"
      self.pm.send('pandaStates', ps)

      time.sleep(0.01)  # 100Hz
      frame_count += 1

  def get_frame_serial(self):
    buffer = bytearray()
    while self.running:
      if self.ser.in_waiting:
        try:
          chunk = self.ser.read(self.ser.in_waiting or 1)
          buffer.extend(chunk)
        except Exception as e:
          print(f"Serial read error: {e}")
          time.sleep(0.1)
          continue

        # Find JPEG Start/End
        soi_idx = buffer.find(b'\xff\xd8')
        eoi_idx = buffer.find(b'\xff\xd9')

        if soi_idx != -1 and eoi_idx != -1 and eoi_idx > soi_idx:
          jpg_data = buffer[soi_idx : eoi_idx + 2]
          buffer = buffer[eoi_idx + 2 :]
          try:
            img = Image.open(io.BytesIO(jpg_data))
            return cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
          except Exception:
            pass
        elif soi_idx == -1 and len(buffer) > 200000:
          buffer = bytearray()  # clear garbage
      else:
        time.sleep(0.001)

  def camera_loop(self):
    cap = None
    if CONNECTION_TYPE == "URL":
      cap = cv2.VideoCapture(ESP32_URL)
    elif CONNECTION_TYPE == "INDEX":
      cap = cv2.VideoCapture(CAMERA_INDEX)
    elif CONNECTION_TYPE == "SERIAL":
      try:
        self.ser = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=0.1)
      except serial.SerialException as e:
        print(f"Error opening serial: {e}")
        return

    frame_id = 0
    while self.running:
      frame = None

      if CONNECTION_TYPE == "SERIAL":
        frame = self.get_frame_serial()
      else:
        ret, read_frame = cap.read()
        if ret:
          frame = read_frame
        else:
          time.sleep(0.1)
          if CONNECTION_TYPE == "URL":
            cap = cv2.VideoCapture(ESP32_URL)

      if frame is None:
        continue

      # Resize to target
      try:
        frame = cv2.resize(frame, (TARGET_W, TARGET_H))
      except Exception:
        continue  # bad frame

      yuv = self.rgb_to_nv12(frame)
      yuv_data = yuv.data.tobytes()

      eof = int(frame_id * 0.05 * 1e9)
      self.vipc_server.send(VisionStreamType.VISION_STREAM_ROAD, yuv_data, frame_id, eof, eof)

      dat = messaging.new_message('roadCameraState')
      dat.valid = True
      dat.roadCameraState = {
        "frameId": frame_id,
        "transform": [1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, 1.0],
        "image": yuv_data[:100],
        "sensor": "unknown",
      }
      self.pm.send('roadCameraState', dat)

      frame_id += 1
      time.sleep(1.0 / FRAMERATE)

  def start(self):
    t_sys = threading.Thread(target=self.publish_system_state)
    t_sys.start()
    try:
      self.camera_loop()
    except KeyboardInterrupt:
      self.running = False
      t_sys.join()
      if self.ser:
        self.ser.close()


if __name__ == "__main__":
  bridge = ESP32Bridge()
  bridge.start()
