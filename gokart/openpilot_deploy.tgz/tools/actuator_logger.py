#!/usr/bin/env python3
import csv
import os
import argparse
import signal
import sys


# Handle SIGINT gracefully
def signal_handler(sig, frame):
  print("\nStopped.")
  sys.exit(0)


signal.signal(signal.SIGINT, signal_handler)


def main():
  parser = argparse.ArgumentParser(description="Log actuator values from Openpilot to a CSV file.")
  parser.add_argument("--output", type=str, default="actuators.csv", help="Path to the output CSV file.")
  parser.add_argument("--rate", type=float, default=100.0, help="Log rate in Hz (default: 100)")
  parser.add_argument("--serial", type=str, default=None, help="Serial port to output data to (e.g., COM3, /dev/ttyUSB0)")
  parser.add_argument("--baud", type=int, default=115200, help="Baud rate for serial output (default: 115200)")
  args = parser.parse_args()

  csv_path = args.output
  print(f"Starting script... Logging to {csv_path}")

  # Serial setup
  ser = None
  if args.serial:
    try:
      import serial

      print(f"Opening serial port {args.serial} at {args.baud} baud...")
      ser = serial.Serial(args.serial, args.baud, timeout=0.1)
      print("Serial port opened.")
    except ImportError:
      print("Error: Could not import 'serial'. Please install pyserial (pip install pyserial).")
      return
    except Exception as e:
      print(f"Error opening serial port: {e}")
      return

  print("Importing messaging...")
  try:
    import cereal.messaging as messaging
  except ImportError:
    print("Error: Could not import cereal.messaging. Ensure you are in the Openpilot environment.")
    return

  print("Messaging imported.")

  print("Initializing SubMaster...")
  sm = messaging.SubMaster(['carOutput'])
  print("SubMaster initialized. Waiting for messages...")

  # Define columns to log
  columns = ['timestamp_ns', 'gas', 'brake', 'steer', 'steeringAngleDeg', 'torque', 'accel', 'speed', 'steeringPressed']

  try:
    with open(csv_path, 'a', newline='') as f:
      writer = csv.writer(f)

      # Write header if file is empty
      if os.path.exists(csv_path) and os.path.getsize(csv_path) == 0:
        writer.writerow(columns)
        f.flush()
        print("Header written.")
      elif not os.path.exists(csv_path):
        writer.writerow(columns)
        f.flush()
        print("Created new file and written header.")

      frame_count = 0

      while True:
        sm.update(int(1000 / args.rate))

        if sm.updated['carOutput']:
          ao = sm['carOutput'].actuatorsOutput

          # Safely get values, defaulting to None if not present (though in capnp they usually have defaults)
          # Note: getattr is used for safety if fields change, though capnp structs are strict.
          row = [
            sm.logMonoTime['carOutput'],
            getattr(ao, 'gas', 0.0),
            getattr(ao, 'brake', 0.0),
            getattr(ao, 'steer', 0.0),  # Normalized steering torque usually
            getattr(ao, 'steeringAngleDeg', 0.0),
            getattr(ao, 'torque', 0.0),  # Some cars use torque request
            getattr(ao, 'accel', 0.0),
            getattr(ao, 'speed', 0.0),
            getattr(ao, 'steeringPressed', False),
          ]

          # Round floats for cleaner CSV
          row = [round(x, 6) if isinstance(x, float) else x for x in row]

          writer.writerow(row)

          # Serial Output
          if ser:
            # Format: gas,brake,steer,steeringAngleDeg,torque,accel,speed,steeringPressed\n
            # Skip timestamp for serial to keep it short
            serial_cols = row[1:]
            serial_line = ",".join(map(str, serial_cols)) + "\n"
            try:
              ser.write(serial_line.encode('utf-8'))
            except Exception as e:
              print(f"Serial write error: {e}")

          frame_count += 1

          if frame_count % 100 == 0:
            f.flush()
            print(f"Logged {frame_count} frames...", end='\r')

  except Exception as e:
    print(f"\nError: {e}")


if __name__ == "__main__":
  main()
