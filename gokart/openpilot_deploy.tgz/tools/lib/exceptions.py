class DataUnreadableError(Exception):
  pass
